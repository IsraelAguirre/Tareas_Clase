/******************************************************************************

Factorial de un numero con do while

*******************************************************************************/
#include <stdio.h>

void main()
{
    int cont=1,numero,fac=1,suma=0;
    
    printf("Cual es el numero factorial que desea realizar:");
    scanf("%i",&numero);
    
    do{
        fac*=cont;
        cont++;
    }
    while(cont<=numero);
    printf("El factoial del numero es:%i",fac);
}
