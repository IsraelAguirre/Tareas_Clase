/******************************************************************************

Realizar un programa en C que, al recibir como dato un entero positivo , obtenga 
e imprima la sucesion de ULAM, la cual se llama asi en honor de matematicos s.Ulam

sucesion Ulam

1.Inicia en cualquier numero positivo
2.Si el numero es par, dividelo entre 2. Si es impar,multiplicalo por 3 y agregale 1
3.Obten sucesivamente numeros enteros repitiendo el proceso

Al final obtendras el numero 1.Por ejemplo, si el entero inicial es 45, la secuencia
es la siguiente 45,136,68,34,17,52,26,13,40,20,10,5,16,8,4,2,16

Dato:N(variable de tipo entero que representa el entero positivo que se ingresa)

*******************************************************************************/
#include <stdio.h>

void main()
{
    	int N;
 
       printf("Ingrese el numero positivo: ");
       scanf("%d",&N);
       
       do{
    	printf("%d  ", N);
		
		if(N%2==0){
			N=N/2;
		}
		 else if (N%2==1) {
			N=(N*3)+1;
		}
		if(N<0){
		    printf("Escriba un numero positivo:");
		    scanf("%d",&N);
		}
		
	}
	while(N!=1);
 
}
